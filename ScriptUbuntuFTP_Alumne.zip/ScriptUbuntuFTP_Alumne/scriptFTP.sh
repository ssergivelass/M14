#!/bin/bash

sudo apt update > /dev/null
sudo apt upgrade > /dev/null

sudo apt install apache2 -y > /dev/null
sudo apt install vsftpd -y > /dev/null
sudo apt install openssh-server -y > /dev/null

sudo service apache2 stop
sudo service vsftpd stop
sudo service ssh stop

sudo cp /etc/vsftpd.conf /etc/vsftpd.conf.old
rm -rf /etc/vsftpd.conf
cp ./validacioFTP.conf /etc/vsftpd.conf

sudo useradd -m gerard > /dev/null
sudo useradd -m sergio > /dev/null
sudo useradd -m alumne > /dev/null


echo "gerard:qweQWE123" | sudo chpasswd 
echo "sergio:qweQWE123" | sudo chpasswd
echo "alumne:qweQWE123" | sudo chpasswd


sudo mkdir /var/www/gerard > /dev/null
sudo mkdir /var/www/sergio > /dev/null
sudo mkdir /var/www/alumne > /dev/null


sudo chown -R gerard:gerard /var/www/gerard > /dev/null
sudo chown -R sergio:sergio /var/www/gerard > /dev/null
sudo chown -R alumne:alumne /var/www/alumne > /dev/null

sudo service ssh start
sudo service apache2 start
sudo service vsftpd start


touch Instruccions.txt
echo """
*********************************************************
EXPLICACIÓ DEL QUE HA REALITZAT L'SCRIPT QUE HEU EXECUTAT
*********************************************************

1.- Actualitzar els repositoris.

2.- Instal·lar el servidor ssh, Apache i el servidor ftp.

3.- Es paren els servidors per poder fer un backup del fitxer de configuració original del FTP. Es reemplaça el fitxer que us hem facilitat per el fitxer que ja tenieu.

4.- Es creen tres usuaris, gerard, sergio i alumne, assignant-lis el password qweQWE123 a cada un d'ells. (Si voleu podeu modificar el password si no us agrada).

5.- Es creen tres directoris (un per cada usuari) dins del directori /var/www i es donen permisos a cada un dels usuaris a aquests directoris.

6.- Es reinicien els serveis de ssh, apache i ftp.

7.- Es mostren els ports oberts en el Ubuntu.



********************
TASQUES A REALITZAR
*********************

1.- Heu de fer que els usuaris creats tinguin accés per ftp als directoris creats en l'script.

2.- Si teniu algun error solucioneu-lo perque poguem accedir-hi.

3.- Si heu modificat el password dels usuaris ens l'heu de comunicar.

4.- Proveu vosaltres primer que podeu accedir-hi abans de la validació. NOMÉS ES VALIDARÀ UN COP.

5.- Com a la pràctica que heu fet anteriorment, els usuaris han d'estar correctament enjaulados.

6.- ES UNA VALIDACIÓ INDIVIDUAL. NO ES POR CONSULTAR ABSOLUTAMENT RES AMB CAP COMPANY NI A CAP TIPUS DE INTEL·LIGÈNCIA ARTIFICIAL!

7.- ÉS OBLIGATORI UTILITZAR EL FITXER DE CONFIGURACIÓ QUE US HEM FACILITAT.
""" > Instruccions.txt

printf "\n\n\n***************************\n"
printf "\nMostrem les connexions actives de l' Ubuntu\n"
printf "\n***************************\n\n"

sudo netstat -atun


